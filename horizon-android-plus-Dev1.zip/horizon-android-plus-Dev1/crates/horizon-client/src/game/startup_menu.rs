//! The interactive title before world resources exist. Uses only the menu
//! atlas/panorama; transfers the actual screen and queued entry to Game.
use super::*;
use horizon_client::{
    clipboard::{self, AppendSelection, SystemClipboard},
    options_ui::{Event, OptionsUi, Page},
};
use winit::{event::KeyEvent, keyboard::ModifiersState};

#[derive(Default)]
pub(super) struct StartupMenu {
    #[cfg(target_os = "android")]
    touch: horizon_client::touch_ui::TouchUi,
    #[cfg(target_os = "android")]
    keyboard_focus: Option<horizon_client::widgets::Target>,
    #[cfg(target_os = "android")]
    keyboard_navigation: bool,
    #[cfg(target_os = "android")]
    controls: horizon_client::touch::TouchControls,
    #[cfg(target_os = "android")]
    pub(super) audio: Option<horizon_client::audio::Audio>,
    #[cfg(target_os = "android")]
    music: horizon_client::music::MusicManager,
    #[cfg(target_os = "android")]
    audio_tick: Option<Instant>,
    pub(super) frame_graph: horizon_client::perf_overlay::FrameGraph,
    pub(super) last_frame: Option<Instant>,
    title: Option<Title>,
    options: OptionsUi,
    options_open: bool,
    /// The credits from Credits & Attribution, and their last frame.
    win: Option<(horizon_client::win_screen::WinScreen, Instant)>,
    root: PathBuf,
    cursor: (f32, f32),
    pointer: (f64, f64),
    modifiers: ModifiersState,
    physical_keys: HashSet<KeyCode>,
    dragging: bool,
    clipboard: SystemClipboard,
    selection: AppendSelection,
    pub pending: Option<PendingWorldEntry>,
    pub reload_packs: bool,
    pub perf: horizon_client::telemetry::Session,
}

impl StartupMenu {
    pub fn new(options: &Options, pack_error: Option<&str>) -> Result<Self> {
        let pending = if let Some(address) = &options.server {
            Some(PendingWorldEntry::Server {
                address: address.clone(),
                name: options.player_name(),
                cookies: None,
            })
        } else {
            options
                .world
                .as_ref()
                .map(|folder| PendingWorldEntry::Local {
                    folder: folder.clone(),
                    name: None,
                    seed: Some(options.seed),
                    creative: options.creative,
                    create: None,
                })
        };
        let mut menu = Self {
            pending,
            ..Default::default()
        };
        menu.root = options.resources.clone();
        if let Some(error) = pack_error {
            menu.options.open_at(false, Page::Packs);
            menu.options.resource_error = Some(error.to_owned());
            menu.options_open = true;
        }
        if menu.pending.is_some() {
            menu.perf.world_opening();
        }
        Ok(menu)
    }

    pub(super) fn set_root(&mut self, root: PathBuf, settings: &Settings) {
        horizon_client::ui::load_metadata(&root);
        horizon_client::lang::set(horizon_client::lang::Language::load(
            &[&root],
            &settings.language,
        ));
        self.root = root;
        #[cfg(target_os = "android")]
        if self.audio.is_none() {
            self.audio = Some(horizon_client::audio::Audio::new(&self.root));
        }
        if self.title.is_none() {
            let mut title = Title::new(
                std::env::current_dir().unwrap_or_default().join("saves"),
                &self.root,
            );
            title.last_server = settings.file.string("lastServer");
            title.skip_multiplayer_warning = settings.file.bool("skipMultiplayerWarning");
            // Gui.addInitialScreens: the accessibility onboarding comes first.
            if settings.file.bool("onboardAccessibility") {
                title.start_onboarding();
            }
            self.title = Some(title);
        }
    }

    pub(super) fn handoff(&mut self, game: &mut Game<'_>) {
        #[cfg(target_os = "android")]
        {
            game.pad.touch = std::mem::take(&mut self.controls);
        }
        #[cfg(target_os = "android")]
        {
            self.audio = None;
            game.music = std::mem::take(&mut self.music);
        }
        game.frame_graph = std::mem::take(&mut self.frame_graph);
        game.title = self
            .title
            .take()
            .map(|title| title.with_user(|| game.options.player_name()));
        game.pending_entry = self.pending.take();
        #[cfg(target_os = "android")]
        if self.keyboard_navigation {
            game.pad.in_use = true;
            game.pad.menu.keyboard_focus = true;
        }
        game.cursor = self.cursor;
        game.modifiers = self.modifiers;
        game.physical_keys = std::mem::take(&mut self.physical_keys);
        game.clipboard = std::mem::take(&mut self.clipboard);
        game.text_selection = std::mem::take(&mut self.selection);
        game.perf = std::mem::take(&mut self.perf);
        // Preserve an existing resource-error screen opened by start_game.
        if self.options_open {
            let resource_error = game.ui.options.resource_error.take();
            game.ui.options = std::mem::take(&mut self.options);
            game.ui.options.resource_error =
                game.ui.options.resource_error.take().or(resource_error);
            game.screen = Screen::Options;
            game.options_from_title = true;
            game.dragging = self.dragging;
        }
    }

    #[cfg(target_os = "android")]
    fn click_sound(&mut self, volumes: [f32; 11]) {
        let audio = self
            .audio
            .get_or_insert_with(|| horizon_client::audio::Audio::new(&self.root));
        audio.master = volumes[0];
        let mut volumes = volumes;
        volumes[0] = 1.0;
        horizon_client::settings::set_source_volumes(volumes);
        audio.tick(false, &Default::default());
        audio.play_button_click();
    }
    fn queue_entry(&mut self, action: Action, player_name: String) {
        let entry = match action {
            Action::Play { folder } => PendingWorldEntry::Local {
                folder,
                name: None,
                seed: None,
                creative: false,
                create: None,
            },
            Action::Create {
                folder,
                name,
                seed,
                creative,
                options,
            } => PendingWorldEntry::Local {
                folder,
                name: Some(name),
                seed,
                creative,
                create: Some(Box::new(options)),
            },
            Action::Connect { address } => PendingWorldEntry::Server {
                address,
                name: player_name,
                cookies: None,
            },
            _ => return,
        };
        self.pending = Some(entry);
        self.perf.world_opening();
    }

    fn shortcut(&mut self, event: &KeyEvent) -> Option<clipboard::EditShortcut> {
        let edit = if cfg!(target_os = "macos") {
            self.modifiers.super_key()
        } else {
            self.modifiers.control_key()
        };
        clipboard::edit_shortcut(
            clipboard::shortcut_letter(&event.logical_key, event.physical_key),
            edit,
            self.modifiers.shift_key(),
            self.modifiers.alt_key(),
        )
    }

    /// `Screen.keyPressed` on the title screens: the action a key starts (Enter confirms, see `confirm_key` in title.rs).
    fn title_key(&mut self, event: &KeyEvent) -> Action {
        let shortcut = self.shortcut(event);
        let Some(title) = &mut self.title else {
            return Action::None;
        };
        if let Some(shortcut) = shortcut {
            if title.has_caret_field() {
                title.field_shortcut(shortcut, &mut self.clipboard);
            } else if let Some((id, value, max)) = title.focused_field()
                && self
                    .selection
                    .apply(id, value, shortcut, &mut self.clipboard, |v, t| {
                        clipboard::append_limited(v, t, max)
                    })
            {
                title.search_changed();
            }
            return Action::None;
        }
        match event.physical_key {
            PhysicalKey::Code(KeyCode::Escape) => title.escape(),
            PhysicalKey::Code(KeyCode::F5) => title.refresh_servers(),
            PhysicalKey::Code(KeyCode::Tab) => title.tab(),
            PhysicalKey::Code(KeyCode::Enter | KeyCode::NumpadEnter) => return title.confirm_key(),
            PhysicalKey::Code(KeyCode::Space) if title.list_focused() => {
                return title.confirm_key();
            }
            PhysicalKey::Code(
                key @ (KeyCode::Backspace
                | KeyCode::Delete
                | KeyCode::ArrowLeft
                | KeyCode::ArrowRight
                | KeyCode::Home
                | KeyCode::End),
            ) if title.has_caret_field() => {
                title.field_key(
                    key,
                    self.modifiers.control_key(),
                    self.modifiers.shift_key(),
                );
            }
            _ => {
                let cleared = !title.has_caret_field()
                    && title
                        .focused_field()
                        .is_some_and(|(id, value, _)| self.selection.take(id, value));
                if cleared {
                    title.search_changed();
                }
                if event.physical_key == PhysicalKey::Code(KeyCode::Backspace) {
                    if !cleared {
                        title.backspace();
                    }
                } else if let Some(text) = &event.text {
                    title.type_text(text);
                }
            }
        }
        Action::None
    }
}

/// A panic's message: its `&str` or `String` payload.
fn panic_text(payload: &(dyn std::any::Any + Send)) -> &str {
    payload
        .downcast_ref::<&str>()
        .copied()
        .or_else(|| payload.downcast_ref::<String>().map(String::as_str))
        .unwrap_or("Box<dyn Any>")
}

/// Each generation has its own channel and progress. Pack changes wait for the
/// old tail before starting another generation, including cache/global writes.
pub(super) fn spawn_loader(
    options: &Options,
    settings: &Settings,
    vanilla_root: &std::path::Path,
    started: Instant,
    progress: &Progress,
) -> Result<(Receiver<LoaderMsg>, JoinHandle<()>)> {
    let (sender, receiver) = std::sync::mpsc::channel();
    let settings = settings.clone();
    let vanilla_root = vanilla_root.to_path_buf();
    let dev_mods = options.dev_mods.clone();
    let progress = progress.clone();
    let handle = std::thread::Builder::new()
        .name("resource-loader".into())
        .spawn(move || {
            let mut pack_error = None;
            let root = packs::startup_root(&vanilla_root, &settings.resource_packs, &[])
                .unwrap_or_else(|error| {
                    pack_error = Some(error.to_string());
                    vanilla_root.clone()
                });
            let root = mods::content_root(&root, &settings.mods.enabled, &dev_mods);
            let result = load_resources(
                root,
                &vanilla_root,
                &settings,
                started,
                true,
                false,
                &progress,
                &mut |gui, root| {
                    let _ = sender.send(LoaderMsg::Ui(gui, root.to_path_buf()));
                },
            )
            .map(|mut loaded| {
                loaded.pack_error = loaded.pack_error.or(pack_error);
                loaded
            })
            .map_err(|error| error.to_string());
            let _ = sender.send(LoaderMsg::Done(result));
        })?;
    Ok((receiver, handle))
}

impl Loading {
    pub(super) fn poll_menu_resources(&mut self) -> Result<()> {
        // Once `Done` arrived the generation is over: the caller may have taken
        // its result, and the finished loader's channel is closed.
        if self.loaded.is_none() && !self.delivered {
            loop {
                match self.receiver.try_recv() {
                    Ok(LoaderMsg::Ui(gui, root)) => self.set_ui(gui, root),
                    Ok(LoaderMsg::Done(result)) => {
                        self.loaded = Some(result);
                        self.delivered = true;
                        break;
                    }
                    Err(TryRecvError::Empty) => break,
                    Err(TryRecvError::Disconnected) => {
                        // The loader sends `Done` before it returns: it panicked.
                        let reason = match self.handle.take().map(JoinHandle::join) {
                            Some(Err(payload)) => panic_text(payload.as_ref()).to_owned(),
                            Some(Ok(())) => "it returned without a result".into(),
                            None => "no loader thread was running".into(),
                        };
                        return Err(
                            format!("resource loader stopped before finishing: {reason}").into(),
                        );
                    }
                }
            }
        }
        self.restart_menu_resources()
    }
    pub(super) fn apply_menu_settings(&mut self) {
        #[cfg(target_os = "android")]
        {
            self.menu.controls.settings = self.settings.touch.clone();
        }
        if let Some(renderer) = &mut self.renderer {
            renderer.gamma = self.settings.gamma;
            renderer.set_present_mode(self.settings.vsync, self.settings.horizon.present_mode);
        }
        horizon_client::hud::GUI_SCALE.store(self.settings.gui_scale, Ordering::Relaxed);
        if let Some(gui) = &mut self.gui {
            gui.atlas.font.uniform = self.settings.force_unicode;
            gui.atlas.font.japanese = self.settings.japanese_glyphs;
        }
        if let Some(window) = self.window.clone() {
            let modes = window
                .current_monitor()
                .or_else(|| window.primary_monitor())
                .map(|m| horizon_client::window::monitor_video_modes(&m))
                .unwrap_or_default();
            let preferred = self
                .settings
                .file
                .fullscreen_resolution
                .as_deref()
                .and_then(horizon_client::window::VideoMode::read);
            self.fullscreen.apply(
                &window,
                self.settings.fullscreen,
                self.settings.file.bool("exclusiveFullscreen"),
                preferred,
                false,
            );
            self.settings.video_modes = modes;
        }
        self.update_menu_cursor();
    }

    fn update_menu_cursor(&mut self) {
        let batch = HudBatch::new(self.menu_size());
        self.menu.cursor = (
            self.menu.pointer.0 as f32 / batch.scale,
            self.menu.pointer.1 as f32 / batch.scale,
        );
    }

    fn menu_size(&self) -> [u32; 2] {
        self.renderer
            .as_ref()
            .map_or([1280, 720], |r| [r.config.width, r.config.height])
    }

    fn save_menu_address(&mut self) {
        if self.menu.title.as_ref().is_some_and(|title| {
            title.last_server != self.settings.file.string("lastServer")
                || title.skip_multiplayer_warning
                    != self.settings.file.bool("skipMultiplayerWarning")
        }) {
            self.save_menu_settings();
        }
    }

    fn save_menu_settings(&mut self) {
        if let Some(title) = &self.menu.title {
            self.settings.file.set(
                "lastServer",
                horizon_client::options_file::V::Str(title.last_server.clone()),
            );
            self.settings.file.set(
                "skipMultiplayerWarning",
                horizon_client::options_file::V::Bool(title.skip_multiplayer_warning),
            );
        }
        self.settings.save(&Game::options_path());
    }

    fn open_menu_options(&mut self, page: Page) {
        self.menu.options.open_at(false, page);
        self.menu.options.languages = horizon_client::lang::available(&[&self.menu.root]);
        self.menu.options.pack_infos = packs::pack_infos(&self.vanilla_root);
        self.menu.options.pack_selection = self.settings.resource_packs.clone();
        self.menu.options.pack_screen = None;
        self.menu.options_open = true;
    }

    fn menu_option_events(&mut self, events: Vec<Event>) {
        for event in events {
            match event {
                #[cfg(target_os = "android")]
                Event::TouchControls => {
                    let size = self.menu_size();
                    self.menu.controls.viewport(size[0], size[1]);
                    self.menu.controls.open_editor();
                }
                Event::Changed => {
                    self.save_menu_settings();
                    self.apply_menu_settings();
                }
                Event::SliderDrag => {
                    self.apply_menu_settings();
                }
                Event::Close if self.menu.options.resource_error.is_some() => {}
                Event::Close => {
                    self.menu.options_open = false;
                    self.menu.dragging = false;
                    self.save_menu_settings();
                }
                Event::Language(code) => {
                    horizon_client::lang::set(horizon_client::lang::Language::load(
                        &[&self.menu.root],
                        &code,
                    ));
                    self.save_menu_settings();
                }
                Event::Packs(_) => {
                    self.save_menu_settings();
                    self.menu.reload_packs = true;
                }
                Event::OpenPackFolder => {
                    let dir = packs::packs_dir();
                    let _ = std::fs::create_dir_all(&dir);
                    packs::open_folder(&dir);
                }
                Event::DataPacks(ids) => {
                    if let Some(title) = &mut self.menu.title {
                        title.set_data_packs(ids);
                    }
                }
                Event::OpenDataPackFolder(dir) => {
                    let _ = std::fs::create_dir_all(&dir);
                    packs::open_folder(&dir);
                }
                Event::OpenModFolder => {
                    let dir = Game::options_path().with_file_name(horizon_client::mod_list::DIR);
                    let _ = std::fs::create_dir_all(&dir);
                    packs::open_folder(&dir);
                }
                Event::ListShaderPacks => {
                    self.settings.shader_packs =
                        horizon_client::shader_pack_list::scan(&Game::shader_packs_dir());
                }
                Event::ShaderPack => self.save_menu_settings(),
                Event::OpenShaderPackFolder => {
                    let dir = Game::shader_packs_dir();
                    let _ = std::fs::create_dir_all(&dir);
                    packs::open_folder(&dir);
                }
                Event::Credits => {
                    if let Some(gui) = &self.gui {
                        let name = self.options.as_ref().map_or_else(
                            || horizon_client::offline_name::generate(0),
                            Options::player_name,
                        );
                        let screen = horizon_client::win_screen::WinScreen::new(
                            false,
                            &self.menu.root,
                            &name,
                            &gui.atlas.font,
                        );
                        self.menu.win = Some((screen, Instant::now()));
                    }
                }
                // Mods' settings pages open only in a running game.
                Event::ModSettings(_) | Event::NativeSettings(_) | Event::NativeButton(..) => {}
                // The startup menu runs before the game opens a control socket.
                Event::ButtonClick => {
                    #[cfg(target_os = "android")]
                    self.menu.click_sound(self.settings.volumes);
                }
                Event::CopyAgentDetails | Event::Volume(..) => {}
            }
        }
    }

    fn menu_options_click(&mut self, drag: bool, right: bool) {
        let size = self.menu_size();
        let batch = HudBatch::new(size);
        let Some(gui) = &self.gui else { return };
        let events = self.menu.options.click(
            &mut self.settings,
            &gui.atlas,
            self.menu.cursor.0,
            self.menu.cursor.1,
            (batch.width, batch.height),
            [size[0] as i32, size[1] as i32],
            drag,
            right,
        );
        self.menu_option_events(events);
    }

    fn menu_action(&mut self, event_loop: &ActiveEventLoop, action: Action) {
        #[cfg(target_os = "android")]
        if !matches!(action, Action::None) {
            self.menu.click_sound(self.settings.volumes);
        }
        match action {
            Action::Quit => crate::game::exit_app(event_loop),
            Action::Options => self.open_menu_options(Page::Main),
            Action::Accessibility => self.open_menu_options(Page::Accessibility),
            Action::Language => self.open_menu_options(Page::Language),
            Action::Sounds => self.open_menu_options(Page::Sound),
            Action::Credits => self.open_menu_options(Page::Credits),
            Action::OpenUri(uri) => super::packs::open_uri(&uri),
            Action::CopyText(text) => {
                use horizon_client::clipboard::Clipboard;
                self.menu.clipboard.set(&text);
            }
            Action::DataPacks { dir, selected } => {
                let resources = self.vanilla_root.clone();
                self.menu.options.open_data_packs(dir, selected, resources);
                self.menu.options_open = true;
            }
            action => {
                let name = self
                    .options
                    .as_ref()
                    .map_or_else(|| "Player".into(), |o| o.player_name());
                self.menu.queue_entry(action, name);
            }
        }
        self.save_menu_address();
    }

    #[cfg(target_os = "android")]
    pub(super) fn menu_android_keyboard(&mut self) {
        use horizon_client::osk::Output;
        if let Some(notice) = crate::documents::poll() {
            if notice.changed {
                self.menu.options.pack_infos =
                    packs::pack_infos(&self.options.as_ref().unwrap().resources);
                self.menu.options.pack_screen = None;
                self.settings.shader_packs =
                    horizon_client::shader_pack_list::scan(&Game::shader_packs_dir());
            }
            log::info!("{}", notice.text);
        }
        for out in crate::platform::poll() {
            match out {
                Output::Text(s) => {
                    if self.menu.options_open {
                        self.menu
                            .options
                            .type_text(&self.gui.as_ref().unwrap().atlas, &s);
                    } else if let Some(t) = &mut self.menu.title {
                        t.type_text(&s);
                    }
                }
                Output::Backspace => {
                    if self.menu.options_open {
                        let e = self.menu.options.key(
                            &mut self.settings,
                            &self.gui.as_ref().unwrap().atlas,
                            KeyCode::Backspace,
                            None,
                        );
                        self.menu_option_events(e);
                    } else if let Some(t) = &mut self.menu.title {
                        t.backspace();
                    }
                }
                Output::Enter | Output::Close => {
                    crate::platform::hide();
                    if let Some(t) = &mut self.menu.title {
                        t.confirm_edit();
                    }
                }
            }
            self.save_menu_address();
        }
    }
    #[cfg(target_os = "android")]
    fn startup_navigation(&mut self, events: &ActiveEventLoop, event: &KeyEvent) -> Result<bool> {
        use horizon_client::{
            gamepad::{self, Button},
            widgets,
        };
        let Some(key) = horizon_client::keypad::resolve_key(event.physical_key, &event.logical_key)
        else {
            return Ok(false);
        };
        if crate::platform::active()
            || self.menu.options.selected_key.is_some()
            || self
                .menu
                .title
                .as_mut()
                .is_some_and(|t| t.has_caret_field())
        {
            return Ok(false);
        }
        let direction = match key {
            KeyCode::ArrowUp => Some(Button::DPadUp),
            KeyCode::ArrowDown => Some(Button::DPadDown),
            KeyCode::ArrowLeft => Some(Button::DPadLeft),
            KeyCode::ArrowRight => Some(Button::DPadRight),
            _ => None,
        };
        let targets = widgets::last_targets();
        if let Some(direction) = direction {
            self.menu.keyboard_navigation = true;
            let rects: Vec<_> = targets.iter().map(|t| t.rect).collect();
            let old = self
                .menu
                .keyboard_focus
                .and_then(|f| gamepad::refind(f.rect, &rects, 2.0));
            let next = old
                .and_then(|i| gamepad::focus_step_rect(rects[i], direction, &rects))
                .or(old)
                .or_else(|| (!targets.is_empty()).then_some(0));
            if let Some(i) = next {
                self.menu.keyboard_focus = Some(targets[i]);
            }
            if let Some(t) = self.menu.keyboard_focus {
                let scale = HudBatch::new(self.menu_size()).scale;
                self.menu_event(
                    events,
                    WindowEvent::CursorMoved {
                        device_id: DeviceId::dummy(),
                        position: winit::dpi::PhysicalPosition::new(
                            f64::from(t.center().0 * scale),
                            f64::from(t.center().1 * scale),
                        ),
                    },
                )?;
            }
            return Ok(true);
        }
        if matches!(key, KeyCode::Enter | KeyCode::NumpadEnter | KeyCode::Space)
            && self.menu.keyboard_focus.is_some()
        {
            self.startup_mouse_button(events, false, true)?;
            self.startup_mouse_button(events, false, false)?;
            self.menu.keyboard_focus = None;
            return Ok(true);
        }
        Ok(false)
    }

    #[cfg(target_os = "android")]
    fn startup_mouse_button(
        &mut self,
        events: &ActiveEventLoop,
        right: bool,
        down: bool,
    ) -> Result<()> {
        self.menu_event(
            events,
            WindowEvent::MouseInput {
                device_id: winit::event::DeviceId::dummy(),
                button: if right {
                    MouseButton::Right
                } else {
                    MouseButton::Left
                },
                state: if down {
                    ElementState::Pressed
                } else {
                    ElementState::Released
                },
            },
        )
    }

    pub(super) fn menu_event(
        &mut self,
        event_loop: &ActiveEventLoop,
        event: WindowEvent,
    ) -> Result<()> {
        #[cfg(target_os = "android")]
        if let WindowEvent::KeyboardInput { event, .. } = &event
            && event.state == ElementState::Pressed
            && self.startup_navigation(event_loop, event)?
        {
            return Ok(());
        }
        #[cfg(target_os = "android")]
        if matches!(event, WindowEvent::Focused(false)) {
            self.menu.touch.cancel();
            for right in self.menu.touch.release_all_mouse() {
                self.startup_mouse_button(event_loop, right, false)?;
            }
            self.menu.dragging = false;
        }
        #[cfg(target_os = "android")]
        if self.menu.controls.editor.is_some() {
            if matches!(&event, WindowEvent::KeyboardInput { event, .. } if event.state == ElementState::Pressed && (event.logical_key == winit::keyboard::Key::Named(winit::keyboard::NamedKey::BrowserBack) || event.physical_key == PhysicalKey::Code(KeyCode::Escape)))
            {
                self.menu.controls.cancel_editor();
                self.settings.touch = self.menu.controls.settings.clone();
                return Ok(());
            }
            if let WindowEvent::Touch(t) = &event {
                use winit::event::TouchPhase;
                let size = self.menu_size();
                self.menu.controls.viewport(size[0], size[1]);
                if t.phase == TouchPhase::Cancelled {
                    self.menu.controls.cancel_editor();
                } else {
                    self.menu.controls.edit_touch(
                        t.id,
                        [
                            t.location.x as f32 / size[0].max(1) as f32,
                            t.location.y as f32 / size[1].max(1) as f32,
                        ],
                        t.phase == TouchPhase::Started,
                        t.phase == TouchPhase::Ended,
                    );
                }
                if self.menu.controls.editor.is_none() {
                    self.settings.touch = self.menu.controls.settings.clone();
                }
                if std::mem::take(&mut self.menu.controls.clicked) {
                    self.menu.click_sound(self.settings.volumes);
                }
                return Ok(());
            }
        }
        #[cfg(target_os = "android")]
        if matches!(&event,WindowEvent::KeyboardInput {event,..} if event.state==ElementState::Pressed && event.logical_key==winit::keyboard::Key::Named(winit::keyboard::NamedKey::BrowserBack))
        {
            if crate::platform::active() {
                crate::platform::hide();
                return Ok(());
            }
            crate::platform::hide();
            if self.menu.options_open {
                let e = self.menu.options.key(
                    &mut self.settings,
                    &self.gui.as_ref().unwrap().atlas,
                    KeyCode::Escape,
                    None,
                );
                self.menu_option_events(e);
            } else if let Some(t) = &mut self.menu.title {
                t.escape();
            }
            return Ok(());
        }
        #[cfg(target_os = "android")]
        if let WindowEvent::Touch(touch) = &event {
            self.menu.keyboard_navigation = false;
            self.menu.keyboard_focus = None;
            use horizon_client::touch_ui::{Action, Gesture};
            use winit::event::TouchPhase;
            let b = HudBatch::new(self.menu_size());
            let p = [
                touch.location.x as f32 / b.scale,
                touch.location.y as f32 / b.scale,
            ];
            if touch.phase == TouchPhase::Ended
                && let Some((right, last)) = self.menu.touch.release_mouse(touch.id)
            {
                if last {
                    self.startup_mouse_button(event_loop, right, false)?;
                }
                return Ok(());
            }
            if touch.phase == TouchPhase::Cancelled {
                self.menu.touch.cancel();
                for right in self.menu.touch.release_all_mouse() {
                    self.startup_mouse_button(event_loop, right, false)?;
                }
                return Ok(());
            }
            if let Some(action) = self.menu.touch.action(b.width, b.height, p, true) {
                if touch.phase == TouchPhase::Started {
                    match action {
                        Action::VirtualMouse => {
                            for right in self.menu.touch.release_all_mouse() {
                                self.startup_mouse_button(event_loop, right, false)?;
                            }
                            self.menu.touch.cancel();
                            self.menu.touch.virtual_mouse ^= true;
                        }
                        Action::MouseButton(right) => {
                            if self.menu.touch.press_mouse(touch.id, right) {
                                self.startup_mouse_button(event_loop, right, true)?;
                            }
                        }
                        Action::More => self.menu.touch.expanded = !self.menu.touch.expanded,
                        Action::Keyboard => {
                            if crate::platform::active() {
                                crate::platform::hide();
                            } else {
                                let initial = self
                                    .menu
                                    .title
                                    .as_mut()
                                    .and_then(|t| {
                                        t.field_key(KeyCode::End, false, false);
                                        t.focused_field().map(|(_, s, _)| s.to_owned())
                                    })
                                    .unwrap_or_default();
                                crate::platform::show(&initial);
                            }
                        }
                        Action::Key(KeyCode::Escape) => {
                            crate::platform::hide();
                            if self.menu.options_open {
                                let events = self.menu.options.key(
                                    &mut self.settings,
                                    &self.gui.as_ref().unwrap().atlas,
                                    KeyCode::Escape,
                                    None,
                                );
                                self.menu_option_events(events);
                            } else if let Some(t) = &mut self.menu.title {
                                t.escape();
                            }
                        }
                        _ => {}
                    }
                }
                return Ok(());
            }
            if self.menu.touch.virtual_mouse {
                let cursor = self.menu.touch.relative_touch(
                    touch.id,
                    p,
                    touch.phase,
                    [self.menu.cursor.0, self.menu.cursor.1],
                    [b.width, b.height],
                    self.settings.touch.virtual_mouse_sensitivity,
                    !self.menu.touch.mouse_held(),
                );
                self.menu_event(
                    event_loop,
                    WindowEvent::CursorMoved {
                        device_id: touch.device_id,
                        position: winit::dpi::PhysicalPosition::new(
                            f64::from(cursor[0] * b.scale),
                            f64::from(cursor[1] * b.scale),
                        ),
                    },
                )?;
                if let Some(right) = self
                    .menu
                    .touch
                    .relative_click(!self.menu.touch.mouse_held())
                {
                    self.startup_mouse_button(event_loop, right, true)?;
                    self.startup_mouse_button(event_loop, right, false)?;
                }
                return Ok(());
            }
            self.menu_event(
                event_loop,
                WindowEvent::CursorMoved {
                    device_id: touch.device_id,
                    position: touch.location,
                },
            )?;
            if self.menu.touch.direct_pointer(touch.id, p, touch.phase) {
                if touch.phase != TouchPhase::Moved {
                    self.menu_event(
                        event_loop,
                        WindowEvent::MouseInput {
                            device_id: touch.device_id,
                            button: MouseButton::Left,
                            state: if touch.phase == TouchPhase::Started {
                                ElementState::Pressed
                            } else {
                                ElementState::Released
                            },
                        },
                    )?;
                }
                return Ok(());
            }
            match self.menu.touch.gesture(
                touch.id,
                [touch.location.x as f32, touch.location.y as f32],
                touch.phase,
            ) {
                Gesture::Tap => {
                    let field = crate::platform::field_at(p);
                    for state in [ElementState::Pressed, ElementState::Released] {
                        self.menu_event(
                            event_loop,
                            WindowEvent::MouseInput {
                                device_id: touch.device_id,
                                button: MouseButton::Left,
                                state,
                            },
                        )?;
                    }
                    if field {
                        let initial = self
                            .menu
                            .title
                            .as_mut()
                            .and_then(|t| {
                                t.field_key(KeyCode::End, false, false);
                                t.focused_field().map(|(_, s, _)| s.to_owned())
                            })
                            .unwrap_or_default();
                        crate::platform::show(&initial);
                    }
                }
                Gesture::Scroll(y) => self.menu_event(
                    event_loop,
                    WindowEvent::MouseWheel {
                        device_id: touch.device_id,
                        delta: MouseScrollDelta::LineDelta(0.0, y),
                        phase: TouchPhase::Moved,
                    },
                )?,
                Gesture::None => {}
            }
            return Ok(());
        }
        if let WindowEvent::KeyboardInput { event, .. } = &event
            && let PhysicalKey::Code(key) = event.physical_key
        {
            if event.state == ElementState::Pressed {
                self.menu.physical_keys.insert(key);
            } else {
                self.menu.physical_keys.remove(&key);
            }
        }
        match event {
            WindowEvent::CloseRequested => {
                if !self.settings.quit_shortcuts
                    && horizon_client::input::is_quit_shortcut_down(
                        self.menu.modifiers,
                        &self.menu.physical_keys,
                    )
                {
                    return Ok(());
                }
                self.save_menu_settings();
                crate::game::exit_app(event_loop);
            }
            WindowEvent::Resized(size) => {
                if let Some(r) = &mut self.renderer {
                    r.resize(size.width, size.height);
                }
                self.apply_menu_settings();
            }
            WindowEvent::RedrawRequested => self.draw(),
            WindowEvent::ModifiersChanged(modifiers) => self.menu.modifiers = modifiers.state(),
            WindowEvent::Focused(false) => {
                self.menu.modifiers = ModifiersState::empty();
                self.menu.physical_keys.clear();
                self.menu.dragging = false;
                if let Some(title) = &mut self.menu.title {
                    title.release();
                    title.release_field();
                }
                let events = self.menu.options.release();
                self.menu_option_events(events);
            }
            WindowEvent::KeyboardInput { event, .. }
                if event.state == ElementState::Pressed && self.menu.pending.is_some() =>
            {
                if event.physical_key == PhysicalKey::Code(KeyCode::Escape) {
                    self.menu.pending = None;
                    self.menu.perf.cancel_world_opening();
                }
            }
            _ if self.gui.is_none() || self.menu.pending.is_some() => {}
            WindowEvent::KeyboardInput { event, .. } if self.menu.win.is_some() => {
                if let PhysicalKey::Code(code) = event.physical_key {
                    let pressed = event.state == ElementState::Pressed;
                    if code == KeyCode::Escape && pressed {
                        self.menu.win = None;
                    } else if let Some(key) = horizon_client::win_screen::Key::from_code(code)
                        && let Some((win, _)) = &mut self.menu.win
                    {
                        win.key(key, pressed);
                    }
                }
            }
            WindowEvent::MouseInput { .. } | WindowEvent::MouseWheel { .. }
                if self.menu.win.is_some() => {}
            WindowEvent::CursorMoved { position, .. } => {
                self.menu.pointer = (position.x, position.y);
                self.update_menu_cursor();
                if self.menu.options_open && self.menu.dragging {
                    self.menu_options_click(true, false);
                } else if let Some(title) = &mut self.menu.title {
                    let size = self
                        .renderer
                        .as_ref()
                        .map_or([1280, 720], |r| [r.config.width, r.config.height]);
                    let b = HudBatch::new(size);
                    title.drag(self.menu.cursor, (b.width, b.height));
                    title.drag_field(&self.gui.as_ref().unwrap().atlas, self.menu.cursor.0);
                }
            }
            WindowEvent::MouseInput { state, button, .. } if self.menu.options_open => {
                if state == ElementState::Pressed && self.menu.options.selected_key.is_some() {
                    let events = self.menu.options.bind_mouse(&mut self.settings, button);
                    self.menu_option_events(events);
                } else if matches!(button, MouseButton::Left | MouseButton::Right) {
                    if state == ElementState::Pressed {
                        self.menu.dragging = button == MouseButton::Left;
                        self.menu_options_click(false, button == MouseButton::Right);
                    } else if button == MouseButton::Left {
                        self.menu.dragging = false;
                        let events = self.menu.options.release();
                        self.menu_option_events(events);
                    }
                }
            }
            WindowEvent::MouseInput {
                state,
                button: MouseButton::Left,
                ..
            } => {
                let batch = HudBatch::new(self.menu_size());
                if let (Some(title), Some(gui)) = (&mut self.menu.title, &self.gui) {
                    if state == ElementState::Released {
                        title.release();
                        title.release_field();
                    } else {
                        let (action, _) = title.click(
                            self.menu.cursor.0,
                            self.menu.cursor.1,
                            (batch.width, batch.height),
                        );
                        title.press_field(
                            &gui.atlas,
                            self.menu.cursor,
                            (batch.width, batch.height),
                            self.menu.modifiers.shift_key(),
                        );
                        title.press_rules(
                            &gui.atlas,
                            self.menu.cursor,
                            (batch.width, batch.height),
                        );
                        self.menu_action(event_loop, action);
                    }
                }
            }
            WindowEvent::MouseWheel { delta, .. } => {
                let raw = match delta {
                    MouseScrollDelta::LineDelta(_, y) => y,
                    MouseScrollDelta::PixelDelta(p) => (p.y / 30.0) as f32,
                };
                let amount = if self.settings.discrete_scroll {
                    horizon_client::mouse::java_signum(f64::from(raw)) as f32
                } else {
                    raw
                } * self.settings.mouse_wheel_sensitivity;
                let size = self.menu_size();
                let batch = HudBatch::new(size);
                if self.menu.options_open {
                    let events = self.menu.options.wheel(
                        &mut self.settings,
                        (batch.width, batch.height),
                        self.menu.cursor,
                        [size[0] as i32, size[1] as i32],
                        amount,
                    );
                    self.menu_option_events(events);
                } else if let Some(title) = &mut self.menu.title {
                    title.scroll_worlds(amount, self.menu.cursor, (batch.width, batch.height));
                }
            }
            WindowEvent::KeyboardInput { event, .. } if event.state == ElementState::Pressed => {
                if event.physical_key == PhysicalKey::Code(KeyCode::F11) {
                    self.settings.fullscreen = !self.settings.fullscreen;
                    self.apply_menu_settings();
                    self.save_menu_settings();
                } else if self.menu.options_open {
                    let shortcut = self.menu.shortcut(&event);
                    let atlas = &self.gui.as_ref().unwrap().atlas;
                    let handled = shortcut.is_some_and(|s| {
                        self.menu
                            .options
                            .shortcut(atlas, s, &mut self.menu.clipboard)
                    });
                    if !handled && let PhysicalKey::Code(key) = event.physical_key {
                        let events = self.menu.options.key(
                            &mut self.settings,
                            atlas,
                            key,
                            event.text.as_deref(),
                        );
                        self.menu_option_events(events);
                    }
                } else {
                    let action = self.menu.title_key(&event);
                    self.menu_action(event_loop, action);
                }
            }
            _ => {}
        }
        Ok(())
    }

    pub(super) fn draw_menu(&mut self, batch: &mut HudBatch) {
        let Some(gui) = &self.gui else { return };
        #[cfg(target_os = "android")]
        if self.menu.keyboard_navigation
            && self.menu.keyboard_focus.is_none()
            && let Some(t) = horizon_client::widgets::last_targets().first().copied()
        {
            self.menu.keyboard_focus = Some(t);
            self.menu.cursor = t.center();
        }
        #[cfg(target_os = "android")]
        if self.menu.controls.editor.is_some() {
            self.menu.controls.draw(batch, &gui.atlas);
            return;
        }
        if self.menu.pending.is_some() {
            horizon_client::level_loading::draw_loading_overlay(
                batch,
                &gui.atlas,
                self.progress.line(),
                self.progress.fraction(),
                self.settings.file.bool("darkMojangStudiosBackground"),
            );
        } else if let Some((win, frame)) = &mut self.menu.win {
            let now = Instant::now();
            // 20 ticks a second: the startup menu runs no tick rate.
            let delta_ticks = now.duration_since(*frame).as_secs_f32() * 20.0;
            *frame = now;
            win.draw(batch, &gui.atlas, delta_ticks, Default::default());
            if win.finished(batch.height) {
                self.menu.win = None;
            }
        } else if self.menu.options_open {
            self.menu
                .options
                .draw(&self.settings, batch, &gui.atlas, self.menu.cursor);
        } else if let Some(title) = &mut self.menu.title {
            title.poll_backup();
            if std::mem::take(&mut title.onboarding_finished) {
                // Options.onboardingAccessibilityFinished.
                self.settings.file.set(
                    "onboardAccessibility",
                    horizon_client::options_file::V::Bool(false),
                );
                self.settings.save(&Game::options_path());
            }
            let _ = title.update_toast(self.settings.notification_display_time);
            title.draw(
                &gui.atlas,
                batch,
                self.menu.cursor,
                self.settings.file.bool("hideSplashTexts"),
            );
        }
        #[cfg(target_os = "android")]
        {
            self.menu.touch.draw(batch, &gui.atlas, true);
            if self.menu.touch.virtual_mouse {
                horizon_client::touch_ui::draw_pointer(batch, &gui.atlas, self.menu.cursor);
            }
        }
        self.menu
            .frame_graph
            .draw(self.settings.horizon.overlay, batch, &gui.atlas);
        #[cfg(target_os = "android")]
        crate::documents::draw(batch, &gui.atlas);
    }

    #[cfg(target_os = "android")]
    pub(super) fn tick_menu_audio(&mut self) {
        let now = Instant::now();
        let last = self.menu.audio_tick.get_or_insert(now);
        if now.duration_since(*last) < Duration::from_millis(50) {
            return;
        }
        *last = now;
        if let Some(audio) = &mut self.menu.audio {
            audio.master = self.settings.volumes[0];
            let mut volumes = self.settings.volumes;
            volumes[0] = 1.0;
            horizon_client::settings::set_source_volumes(volumes);
            let music = horizon_client::music::Music::menu();
            let frequency = horizon_client::music::MusicFrequency::parse(
                &self.settings.file.name("musicFrequency"),
            );
            if self.menu.music.frequency != frequency {
                self.menu.music.set_frequency(frequency, Some(&music));
            }
            self.menu
                .music
                .tick(Some(&music), 1.0, self.menu.pending.is_some(), audio);
            audio.tick(false, &Default::default());
        }
    }

    pub(super) fn restart_menu_resources(&mut self) -> Result<()> {
        if !self.menu.reload_packs || self.loaded.is_none() {
            return Ok(());
        }
        if self
            .renderer_job
            .as_ref()
            .is_some_and(|job| !job.is_finished())
        {
            return Ok(());
        }
        if let Some(job) = self.renderer_job.take() {
            let _ = job.join();
        }
        self.prepared_renderer = None;
        if let Some(Ok(loaded)) = &mut self.loaded {
            if let Some(loader) = &loaded.rest_loader
                && !loader.ready()?
            {
                return Ok(());
            }
            if let Some(loader) = loaded.rest_loader.take()
                && let Err(error) = loader.finish()
            {
                log::warn!("Horizon: replaced resource generation failed: {error}");
            }
        }
        self.loaded = None;
        self.delivered = false;
        if let Some(handle) = self.handle.take() {
            handle.join().map_err(|payload| {
                format!("resource loader panicked: {}", panic_text(payload.as_ref()))
            })?;
        }
        self.progress = Progress::new();
        let options = self.options.as_ref().ok_or("loading already finished")?;
        let (receiver, handle) = spawn_loader(
            options,
            &self.settings,
            &self.vanilla_root,
            self.started,
            &self.progress,
        )?;
        self.receiver = receiver;
        self.handle = Some(handle);
        self.menu.reload_packs = false;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn gui(root: &std::path::Path) -> UiResources {
        UiResources {
            atlas: HudAtlas::fonts(root).unwrap(),
            panorama: Arc::new(horizon_client::gfx::panorama::Faces {
                size: 1,
                pixels: [96, 110, 111, 255].repeat(6),
            }),
        }
    }

    fn loading(receiver: Receiver<LoaderMsg>) -> Loading {
        Loading {
            window: None,
            renderer: None,
            gui: None,
            settings: Settings::default(),
            fullscreen: horizon_client::window::FullscreenState::new(false),
            options: None,
            vanilla_root: PathBuf::new(),
            pack_error: None,
            started: Instant::now(),
            panorama_rotation: Default::default(),
            progress: Progress::new(),
            receiver,
            loaded: None,
            renderer_job: None,
            prepared_renderer: None,
            delivered: false,
            handle: None,
            shown: false,
            menu: StartupMenu::default(),
            error: None,
        }
    }

    #[test]
    fn renderer_preparation_does_not_wait_for_its_worker() {
        let (_sender, receiver) = std::sync::mpsc::channel();
        let (release, wait) = std::sync::mpsc::channel();
        let mut loading = loading(receiver);
        loading.renderer_job = Some(std::thread::spawn(move || {
            wait.recv().unwrap();
            Err("test renderer failure".into())
        }));
        loading.prepare_renderer().unwrap();
        assert!(!loading.renderer_job.as_ref().unwrap().is_finished());
        release.send(()).unwrap();
        while !loading.renderer_job.as_ref().unwrap().is_finished() {
            std::thread::yield_now();
        }
        assert!(
            loading
                .prepare_renderer()
                .unwrap_err()
                .to_string()
                .contains("test renderer failure")
        );
        assert!(loading.renderer_job.is_none());
    }

    #[test]
    fn performance_overlay_is_available_before_the_core_finishes() {
        let (_sender, receiver) = std::sync::mpsc::channel();
        let mut loading = loading(receiver);
        let root = std::env::temp_dir().join("horizon-early-overlay-no-world-data");
        loading.gui = Some(gui(&root));
        loading.settings.horizon.overlay = horizon_client::graphics::Overlay::Fps;
        loading.menu.frame_graph.record(20.0, 4.0, None);
        let mut batch = HudBatch::new([1280, 720]);
        loading.draw_menu(&mut batch);
        assert!(!batch.vertices.is_empty());
        assert!(loading.loaded.is_none());
    }

    #[test]
    fn menu_is_usable_while_the_core_worker_is_blocked() {
        let root = std::env::temp_dir().join("horizon-startup-menu-no-world-resources");
        let (sender, receiver) = std::sync::mpsc::channel();
        let (release, wait) = std::sync::mpsc::channel();
        let (published, published_rx) = std::sync::mpsc::channel();
        let worker_root = root.clone();
        let worker = std::thread::spawn(move || {
            sender
                .send(LoaderMsg::Ui(gui(&worker_root), worker_root))
                .unwrap();
            published.send(()).unwrap();
            wait.recv().unwrap();
            sender
                .send(LoaderMsg::Done(Err("core failure".into())))
                .unwrap();
        });
        published_rx.recv().unwrap();
        let mut loading = loading(receiver);
        loading.poll_menu_resources().unwrap();
        assert!(loading.gui.is_some());
        assert!(loading.loaded.is_none());
        assert!(!worker.is_finished());
        // Navigate and enter a world name without a registry, biomes, pack
        // tables or a Game. Replacing fallback artwork preserves this state.
        let title = loading.menu.title.as_mut().unwrap();
        title.mode = horizon_client::title::Mode::Create {
            name: String::new(),
            seed: "42".into(),
            creative: true,
            focus: 0,
            options: Default::default(),
        };
        title.type_text("My world");
        loading.set_ui(gui(&root), root);
        let action = loading.menu.title.as_ref().unwrap().create_action();
        loading.menu.queue_entry(action, "Player".into());
        assert!(
            matches!(&loading.menu.pending, Some(PendingWorldEntry::Local {
            name: Some(name), seed: Some(42), creative: true, create: Some(_), ..
        }) if name == "My world")
        );
        let mut batch = HudBatch::new([1280, 720]);
        loading.draw_menu(&mut batch);
        assert!(
            !batch.vertices.is_empty(),
            "queued entry draws loading progress"
        );
        release.send(()).unwrap();
        worker.join().unwrap();
        loading.poll_menu_resources().unwrap();
        assert!(matches!(loading.loaded, Some(Err(ref error)) if error == "core failure"));
    }

    #[test]
    fn queued_server_keeps_address_and_player_identity() {
        let mut menu = StartupMenu::default();
        menu.queue_entry(
            Action::Connect {
                address: "localhost:25565".into(),
            },
            "Guest".into(),
        );
        assert!(
            matches!(menu.pending.take(), Some(PendingWorldEntry::Server { address, name, .. })
            if address == "localhost:25565" && name == "Guest")
        );
        assert!(menu.pending.take().is_none(), "an entry is consumed once");
    }

    #[test]
    fn a_failed_generation_keeps_its_error_after_the_loader_ends() {
        let (sender, receiver) = std::sync::mpsc::channel();
        let worker = std::thread::spawn(move || {
            sender
                .send(LoaderMsg::Done(Err("missing facts.json".into())))
                .unwrap();
        });
        let mut loading = loading(receiver);
        loading.handle = Some(worker);
        while loading.loaded.is_none() {
            loading.poll_menu_resources().unwrap();
        }
        // App::about_to_wait takes the result to report it; the loop may poll
        // once more before it exits, with the loader gone.
        assert!(matches!(loading.loaded.take(), Some(Err(e)) if e == "missing facts.json"));
        while !loading.handle.as_ref().is_none_or(JoinHandle::is_finished) {
            std::thread::yield_now();
        }
        loading.poll_menu_resources().unwrap();
        assert!(loading.loaded.is_none());
    }

    #[test]
    fn a_panicking_loader_reports_its_panic() {
        let (sender, receiver) = std::sync::mpsc::channel::<LoaderMsg>();
        let worker = std::thread::spawn(move || {
            let _sender = sender;
            panic!("atlas has no fonts");
        });
        while !worker.is_finished() {
            std::thread::yield_now();
        }
        let mut loading = loading(receiver);
        loading.handle = Some(worker);
        assert_eq!(
            loading.poll_menu_resources().unwrap_err().to_string(),
            "resource loader stopped before finishing: atlas has no fonts"
        );
    }

    #[test]
    fn disconnected_core_worker_is_reported_instead_of_waiting_forever() {
        let (sender, receiver) = std::sync::mpsc::channel();
        drop(sender);
        let mut loading = loading(receiver);
        assert_eq!(
            loading.poll_menu_resources().unwrap_err().to_string(),
            "resource loader stopped before finishing: no loader thread was running"
        );
    }
}
