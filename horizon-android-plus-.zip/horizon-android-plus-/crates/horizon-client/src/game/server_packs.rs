//! A server's resource packs bound to the game (`ClientCommonPacketListenerImpl.
//! handleResourcePackPush` and `handleResourcePackPop`, its `PackConfirmScreen`,
//! and `DownloadedPackSource` as `Minecraft` drives it): the prompt, the
//! server list's setting, downloads into `downloads/`, and a resource reload
//! with the server's packs on top of the player's own.
use super::{Game, packs::ReloadKind};
use horizon_client::{
    Result,
    confirm_screen::Confirm,
    hud::{HudAtlas, HudBatch},
    java_text, multiplayer, packs,
    scoreboard::{comp_text, tag_to_json},
    server_packs::{Prompt, ServerPacks, action, download, parse_sha1, valid_url},
    text::{Text, named_color},
    toasts::SystemToast,
    ui,
};
use horizon_core::jmath;
use horizon_protocol::{packets::configuration::ResourcePackPush, servers};
use std::{
    path::PathBuf,
    sync::mpsc::{Receiver, TryRecvError},
};

/// `ClientCommonPacketListenerImpl.PackConfirmScreen`: the packs it asks
/// about, whether the last one is required, and the server's message.
pub(super) struct PackPrompt {
    requests: Vec<(u128, String, String)>,
    required: bool,
    prompt: Option<Text>,
}
impl PackPrompt {
    fn texts(&self) -> (Text, Text, [Text; 2]) {
        let t = |key: &str| Text::translate(key, &[]);
        let (title, line2) = if self.required {
            let yellow = named_color("yellow").unwrap_or(0xFFFF55);
            (
                t("multiplayer.requiredTexturePrompt.line1"),
                t("multiplayer.requiredTexturePrompt.line2")
                    .with_color(yellow)
                    .bold(),
            )
        } else {
            (
                t("multiplayer.texturePrompt.line1"),
                t("multiplayer.texturePrompt.line2"),
            )
        };
        // preparePackPrompt.
        let message = match &self.prompt {
            Some(prompt) => Text::translate(
                "multiplayer.texturePrompt.serverPrompt",
                &[line2, prompt.clone()],
            ),
            None => line2,
        };
        let buttons = if self.required {
            [t("gui.proceed"), t("menu.disconnect")]
        } else {
            [t("gui.yes"), t("gui.no")]
        };
        (title, message, buttons)
    }
    fn layout(&self, atlas: &HudAtlas, size: (f32, f32)) -> Confirm {
        let (title, message, _) = self.texts();
        Confirm::new(&atlas.font, size, &title, &message)
    }
}

impl ServerPackState {
    /// The `ToastManager` slots the download toasts hold.
    pub(super) fn toast_slots(&self) -> impl Iterator<Item = usize> + '_ {
        self.notifiers
            .iter()
            .filter_map(|n| n.toast.as_ref())
            .chain(self.load_fail.as_ref())
            .chain(self.chunk_io.iter().flatten())
            .chain(self.shader_progress.as_ref())
            .chain(self.shader_notifications.iter().flatten())
            .filter_map(|t| t.slot)
    }
}

/// The game's `DownloadedPackSource`.
#[derive(Default)]
pub(super) struct ServerPackState {
    packs: ServerPacks,
    /// `downloads/` in the game folder, opened at the first download.
    queue: Option<download::Queue>,
    pub(super) prompt: Option<PackPrompt>,
    /// The server list entry the setting is saved to (none: a direct join).
    pub(super) address: Option<String>,
    /// The account the downloads are made for (the download headers).
    user: (String, u128),
    /// The packs loaded on top of the player's own, bottom first.
    pub(super) active: Vec<packs::Pack>,
    /// The download batches' notifiers, oldest first.
    notifiers: Vec<PackNotifier>,
    /// `SystemToastId.PACK_LOAD_FAILURE`: the toast `Minecraft.clearResourcePacksOnError` adds.
    pub(super) load_fail: Option<SystemToast>,
    /// `SystemToastId.LOW_DISK_SPACE`, `CHUNK_LOAD_FAILURE` and `CHUNK_SAVE_FAILURE`:
    /// the toasts the integrated server's chunk IO reports add (`chunk_io`).
    pub(super) chunk_io: [Option<SystemToast>; 3],
    /// The local shader importer runs on its own worker while gameplay continues.
    shader_progress: Option<SystemToast>,
    shader_progress_message: Option<String>,
    shader_notifications: Vec<Option<SystemToast>>,
}
/// `DownloadedPackSource.createDownloadNotifier`: one batch's progress in its
/// own `SystemToast`.
struct PackNotifier {
    progress: Receiver<download::Progress>,
    total: usize,
    /// `count`: the requests started.
    count: usize,
    /// `failCount`.
    failed: usize,
    /// `totalBytes`: the Content-Length of the request in flight.
    size: Option<u64>,
    /// The bytes it has written so far: none before the first response.
    bytes: Option<u64>,
    /// The last request has finished.
    done: bool,
    toast: Option<SystemToast>,
}
impl PackNotifier {
    fn new(progress: Receiver<download::Progress>, total: usize) -> Self {
        Self {
            progress,
            total,
            count: 0,
            failed: 0,
            size: None,
            bytes: None,
            done: false,
            toast: None,
        }
    }
    /// The batch's events since the last call, with the toast updated once
    /// for all of them. False once the batch has ended and its toast is gone.
    fn poll(&mut self) -> bool {
        let (mut changed, mut hide) = (false, false);
        let ended = loop {
            let event = match self.progress.try_recv() {
                Ok(event) => event,
                Err(e) => break e == TryRecvError::Disconnected,
            };
            changed |= match event {
                download::Progress::RequestStart => {
                    self.count += 1;
                    true
                }
                download::Progress::DownloadStart(size) => {
                    self.size = size;
                    self.bytes = Some(0);
                    true
                }
                download::Progress::Bytes(bytes) => {
                    self.bytes = Some(bytes);
                    true
                }
                download::Progress::RequestFinished(ok) => {
                    self.failed += usize::from(!ok);
                    self.done = self.count == self.total;
                    // Every pack came: forceHide; else the failure title.
                    hide |= self.done && self.failed == 0;
                    self.done && self.failed > 0
                }
            };
        };
        if changed {
            let (title, message) = self.text();
            let (title, message) = (title.plain(), message.map(|m| m.plain()));
            // SystemToast.addOrUpdate.
            match &mut self.toast {
                Some(toast) => toast.reset(title, message),
                None => self.toast = Some(SystemToast::new(title, message)),
            }
        }
        if hide && let Some(toast) = &mut self.toast {
            toast.force_hide();
        }
        !ended || self.toast.is_some()
    }
    /// The toast's title and message.
    fn text(&self) -> (Text, Option<Text>) {
        if self.done && self.failed > 0 {
            let failed = Text::tr("download.pack.failed", &[&self.failed, &self.total]);
            return (failed, None);
        }
        let title = Text::tr("download.pack.title", &[&self.count, &self.total]);
        let message = self.bytes.map(|bytes| match self.size {
            Some(size) if size > 0 => {
                Text::tr("download.pack.progress.percent", &[&(bytes * 100 / size)])
            }
            _ => Text::tr("download.pack.progress.bytes", &[&human_readable(bytes)]),
        });
        (title, message)
    }
}
/// `com.mojang.realmsclient.Unit.humanReadable`, for
/// `download.pack.progress.bytes`.
fn human_readable(bytes: u64) -> String {
    if bytes < 1024 {
        return format!("{bytes} B");
    }
    let exp = (jmath::log(bytes as f64) / jmath::log(1024.0)) as i32;
    let prefix = &"KMGTPE"[exp as usize - 1..exp as usize];
    let value = bytes as f64 / 1024f64.powi(exp);
    format!("{} {prefix}B", java_text::format_fixed(value, 1))
}

pub(super) fn saves() -> PathBuf {
    std::env::current_dir().unwrap_or_default().join("saves")
}

/// `WorldOpenFlows.WORLD_PACK_ID`: the id of a world's own resource pack.
const WORLD_PACK_ID: u128 = 0x640a6a92_b6cb_48a0_b391_831586500359;

impl Game<'_> {
    /// `WorldOpenFlows.loadBundledResourcePack`: a world's own
    /// `resourcepacks/resources.zip` is pushed as a local pack before the world
    /// connects, after `configureForLocalWorld` so the pack is accepted at once.
    pub(super) fn server_packs_world_pack(&mut self, folder: &str) {
        let path = saves()
            .join(folder)
            .join("resourcepacks")
            .join("resources.zip");
        if path.is_file() {
            self.server_packs.packs.local_world();
            self.server_packs.packs.push_local(WORLD_PACK_ID, path);
        }
    }
    /// `ConnectScreen`: the server's setting decides what its packs do
    /// (`configureForServerControl`); single player's own server takes them
    /// all, quietly (`configureForLocalWorld`).
    pub(super) fn server_packs_connect(&mut self, address: Option<&str>, user: (String, u128)) {
        let state = &mut self.server_packs;
        state.user = user;
        state.prompt = None;
        state.notifiers.clear();
        let Some(address) = address else {
            state.address = None;
            state.packs.local_world();
            return;
        };
        let file = multiplayer::servers_file(&saves());
        let entry = servers::load(&file).into_iter().find(|s| s.ip == address);
        let setting = entry.as_ref().and_then(|e| e.accept_textures);
        state.address = entry.map(|e| e.ip);
        state.packs.connect(Prompt::for_server(setting));
    }
    /// `Minecraft.clearDownloadedResourcePacks`: every server pack goes at once.
    pub(super) fn server_packs_disconnect(&mut self) {
        self.server_packs.prompt = None;
        self.server_packs.notifiers.clear();
        self.server_packs.packs.disconnect();
        self.tick_server_packs();
    }

    /// `handleResourcePackPush`.
    pub(super) fn handle_pack_push(&mut self, p: ResourcePackPush) {
        if !valid_url(&p.url) {
            self.send_pack_status(p.id, action::INVALID_URL);
            return;
        }
        let setting = self.server_setting();
        let prompt = Prompt::for_server(setting);
        if prompt != Prompt::Pending && (!p.required || prompt != Prompt::Declined) {
            self.server_packs
                .packs
                .push(p.id, &p.url, parse_sha1(&p.hash));
            return;
        }
        // addOrUpdatePackPrompt: one prompt for every pack pushed before it is answered.
        let text = p.prompt.as_ref().map(|t| comp_text(&tag_to_json(t)));
        let state = &mut self.server_packs;
        let open = state.prompt.get_or_insert(PackPrompt {
            requests: Vec::new(),
            required: p.required,
            prompt: None,
        });
        open.requests.push((p.id, p.url, p.hash));
        open.required = p.required;
        open.prompt = text;
        // Gui.setScreen: KeyMapping.releaseAll, so no walking behind the prompt.
        self.keys.clear();
        self.capture(false);
    }
    /// `handleResourcePackPop`: one pack, or all of them.
    pub(super) fn handle_pack_pop(&mut self, id: Option<u128>) {
        match id {
            Some(id) => self.server_packs.packs.pop(id),
            None => self.server_packs.packs.pop_all(),
        }
    }
    /// The joined server's entry in the server list: its `acceptTextures`.
    fn server_setting(&self) -> Option<bool> {
        let address = self.server_packs.address.as_deref()?;
        servers::load(&multiplayer::servers_file(&saves()))
            .into_iter()
            .find(|s| s.ip == address)?
            .accept_textures
    }
    fn send_pack_status(&self, id: u128, status: i32) {
        if let Some(r) = &self.remote {
            r.session.send_pack_status(id, status);
        }
    }

    /// The prompt's answer (`PackConfirmScreen`'s callback): the server's
    /// setting follows it, declining a required pack disconnects, and every
    /// pack it asked about is pushed.
    pub(super) fn answer_pack_prompt(&mut self, yes: bool) -> Result<()> {
        let Some(prompt) = self.server_packs.prompt.take() else {
            return Ok(());
        };
        if self.player.is_some() && self.screen == super::Screen::Playing {
            self.capture(true);
        }
        let setting = if yes {
            self.server_packs.packs.allow();
            Some(true)
        } else {
            self.server_packs.packs.reject();
            if prompt.required {
                let reason = Text::translate("multiplayer.requiredTexturePrompt.disconnect", &[]);
                return self.leave_server(Some(reason.plain()));
            }
            Some(false)
        };
        for (id, url, hash) in prompt.requests {
            self.server_packs.packs.push(id, &url, parse_sha1(&hash));
        }
        // ServerList.saveSingleServer.
        if let Some(address) = &self.server_packs.address {
            let file = multiplayer::servers_file(&saves());
            let mut list = servers::load(&file);
            for entry in list.iter_mut().filter(|s| &s.ip == address) {
                entry.accept_textures = setting;
            }
            if let Err(e) = servers::save(&file, &list) {
                log::warn!("Horizon: could not save {}: {e}", file.display());
            }
        }
        Ok(())
    }

    /// Runs what the packs need (`createUpdateScheduler`): the downloads
    /// that finished, the ones to start, a resource reload when the active
    /// packs change, and the statuses for the server.
    pub(super) fn tick_server_packs(&mut self) {
        self.server_packs.notifiers.retain_mut(PackNotifier::poll);
        // A reload waits for the world's resources (`reload_packs`).
        if self.rest_loader.is_some() || self.world_loader.is_some() {
            return;
        }
        self.drive_pack_reload();
        // One reload at a time: the player's own waits under its overlay
        // before the server's packs can ask for theirs (`ServerPacks` keeps
        // its own reload from overlapping).
        let selection_reloading = self
            .pack_reload
            .as_ref()
            .is_some_and(|r| r.kind() == ReloadKind::Selection);
        let finished = self
            .server_packs
            .queue
            .as_ref()
            .map(download::Queue::finished)
            .unwrap_or_default();
        for batch in finished {
            self.server_packs.packs.downloaded(batch);
        }
        while !selection_reloading && self.server_packs.packs.wants_tick() {
            let tick = self.server_packs.packs.tick();
            if !tick.download.is_empty() {
                self.start_pack_downloads(tick.download);
            }
            if let Some(load) = tick.reload {
                self.start_pack_reload(&load);
            }
        }
        for (id, status) in self.server_packs.packs.take_replies() {
            self.send_pack_status(id, status);
        }
    }
    fn start_pack_downloads(&mut self, requests: Vec<horizon_client::server_packs::Request>) {
        let state = &mut self.server_packs;
        if state.queue.is_none() {
            let dir = std::env::current_dir()
                .unwrap_or_default()
                .join("downloads");
            match download::Queue::open(dir) {
                Ok(queue) => state.queue = Some(queue),
                Err(e) => {
                    log::error!("Horizon: failed to open the download queue: {e}");
                    // Every request failed, as the notifier would hear it.
                    let (progress, events) = std::sync::mpsc::channel();
                    for _ in &requests {
                        let _ = progress.send(download::Progress::RequestStart);
                        let _ = progress.send(download::Progress::RequestFinished(false));
                    }
                    state
                        .notifiers
                        .push(PackNotifier::new(events, requests.len()));
                    let failed = requests.iter().map(|r| r.id).collect();
                    state.packs.downloaded(horizon_client::server_packs::Batch {
                        downloaded: Vec::new(),
                        failed,
                    });
                    return;
                }
            }
        }
        let headers = download::headers(&state.user.0, state.user.1);
        let (progress, events) = std::sync::mpsc::channel();
        state
            .notifiers
            .push(PackNotifier::new(events, requests.len()));
        if let Some(queue) = &state.queue {
            queue.download(requests, headers, progress);
        }
    }
    /// `DownloadedPackSource.startReload`: the packs on top of the player's
    /// own, staged on a worker (`Minecraft.reloadResourcePacks` under a
    /// `LoadingOverlay`); `drive_pack_reload` applies it. A pack with no
    /// readable `pack.mcmeta` fails the reload at once, as `onFailure`.
    fn start_pack_reload(&mut self, load: &[(u128, PathBuf)]) {
        let server: Option<Vec<_>> = load
            .iter()
            .map(|(id, path)| packs::server_pack(*id, path))
            .collect();
        let Some(server) = server else {
            log::warn!("Horizon: invalid pack metadata in a server pack, ignoring all");
            self.finish_pack_reload(false);
            return;
        };
        self.server_packs.active = server;
        if let Err(e) = self.spawn_pack_reload(ReloadKind::Server) {
            log::error!("Horizon: could not start the pack reload worker: {e}");
            self.finish_pack_reload(false);
        }
    }
    /// `ServerPacks::reloaded` and the recovery reload it can ask for.
    pub(super) fn finish_pack_reload(&mut self, ok: bool) {
        if let Some(recovery) = self.server_packs.packs.reloaded(ok) {
            self.start_pack_reload(&recovery);
        }
    }

    pub(super) fn draw_pack_prompt(&self, batch: &mut HudBatch) {
        let Some(prompt) = &self.server_packs.prompt else {
            return;
        };
        let atlas = &self.gui.atlas;
        let (w, h) = (batch.width, batch.height);
        if self.player.is_none() {
            // In place of the connecting screen, on its background.
            batch.fill(
                atlas,
                0.0,
                0.0,
                w,
                h,
                horizon_client::hud::rgba(20, 20, 20, 255),
            );
        }
        ui::menu_background(batch, atlas, 0.0, 0.0, w, h, self.player.is_some());
        let (_, _, [yes, no]) = prompt.texts();
        prompt
            .layout(atlas, (w, h))
            .draw(batch, atlas, self.cursor, [&yes, &no]);
    }
    /// `IntegratedServer.reportChunkLoadFailure` and the like: what the server
    /// thread reported since the last frame, each in `SystemToast.addOrUpdate`
    /// (a toast still shown is reset, else a new one).
    fn add_chunk_io_toasts(&mut self) {
        let pending = horizon_client::chunk_io::take();
        let toasts = [
            pending
                .low_disk_space
                .then(horizon_client::chunk_io::low_disk_space_toast),
            pending
                .load_failure
                .map(|(x, z)| horizon_client::chunk_io::load_failure_toast(x, z)),
            pending
                .save_failure
                .map(|(x, z)| horizon_client::chunk_io::save_failure_toast(x, z)),
        ];
        for (slot, new) in self.server_packs.chunk_io.iter_mut().zip(toasts) {
            match (slot.as_mut(), new) {
                (Some(shown), Some(new)) => shown.reset_from(new),
                (None, Some(new)) => *slot = Some(new),
                _ => {}
            }
        }
    }

    /// The download notifiers' toasts, each in a free 32-pixel slot of the
    /// `ToastManager` (`hidden`, F1, keeps them timing out undrawn).
    pub(super) fn draw_pack_toasts(&mut self, batch: &mut HudBatch, hidden: bool) {
        let multiplier = f64::from(self.settings.notification_display_time);
        self.add_chunk_io_toasts();
        let shader_progress: Option<(bool, bool, String, u8)> = {
            #[cfg(target_os = "android")]
            {
                crate::documents::progress_snapshot().map(|progress| {
                    (progress.active, progress.convert, progress.stage, progress.percent)
                })
            }
            #[cfg(not(target_os = "android"))]
            { None }
        };
        let shader_notifications: Vec<(String, String)> = {
            #[cfg(target_os = "android")]
            {
                crate::documents::take_game_notifications()
                    .into_iter()
                    .map(|notification| (notification.title, notification.message))
                    .collect()
            }
            #[cfg(not(target_os = "android"))]
            { Vec::new() }
        };
        {
            let packs = &mut self.server_packs;
            if let Some((true, convert, stage, percent)) = shader_progress.as_ref() {
                let title = if *convert { "Converting shader pack" } else { "Importing shader pack" };
                let rounded = (*percent / 5) * 5;
                let message = format!("{} · {}%", stage, rounded);
                if packs.shader_progress_message.as_deref() != Some(message.as_str()) {
                    match packs.shader_progress.as_mut() {
                        Some(toast) => toast.reset(title.into(), Some(message.clone())),
                        None => {
                            packs.shader_progress = Some(
                                SystemToast::new(title.into(), Some(message.clone()))
                                    .with_display_time(86_400_000.0),
                            );
                        }
                    }
                    packs.shader_progress_message = Some(message);
                }
            } else {
                if let Some(toast) = packs.shader_progress.as_mut() {
                    toast.force_hide();
                }
                packs.shader_progress_message = None;
            }
            for (title, message) in shader_notifications {
                packs.shader_notifications.push(Some(
                    SystemToast::new(title, Some(message)).with_display_time(9_000.0),
                ));
            }
            while packs.shader_notifications.len() > 4 {
                packs.shader_notifications.remove(0);
            }
        }
        let mut used = self.toast_slots_used();
        let packs = &mut self.server_packs;
        for slot_toast in packs
            .notifiers
            .iter_mut()
            .map(|n| &mut n.toast)
            .chain(std::iter::once(&mut packs.load_fail))
            .chain(packs.chunk_io.iter_mut())
            .chain(std::iter::once(&mut packs.shader_progress))
            .chain(packs.shader_notifications.iter_mut())
        {
            let Some(toast) = slot_toast else {
                continue;
            };
            if toast.slot.is_none() {
                let Some(slot) = (0..Self::TOAST_SLOTS).find(|s| used & (1 << s) == 0) else {
                    continue;
                };
                used |= 1 << slot;
                toast.slot = Some(slot);
            }
            let (sound, finished) = toast.update(multiplier);
            if let Some(show) = sound {
                let event = if show { "ui.toast.in" } else { "ui.toast.out" };
                self.audio
                    .play(&format!("minecraft:{event}"), None, 1.0, 1.0);
            }
            if finished {
                *slot_toast = None;
                continue;
            }
            if let (false, Some(slot)) = (hidden, toast.slot) {
                toast.draw(&self.gui.atlas, batch, 32.0 * slot as f32);
            }
        }
        packs.shader_notifications.retain(|notification| notification.is_some());
        if packs.shader_progress.is_none() {
            packs.shader_progress_message = None;
        }
    }
    /// A left click on the prompt: its answer when it hit a button.
    pub(super) fn pack_prompt_click(&mut self) -> Result<()> {
        let Some(prompt) = &self.server_packs.prompt else {
            return Ok(());
        };
        let answer = prompt
            .layout(&self.gui.atlas, self.gui_size())
            .answer_at(self.cursor);
        match answer {
            Some(yes) => {
                self.audio.play_button_click();
                self.answer_pack_prompt(yes)
            }
            None => Ok(()),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use download::Progress::*;

    fn notifier(total: usize, events: &[download::Progress]) -> PackNotifier {
        let (send, receive) = std::sync::mpsc::channel();
        for event in events {
            send.send(*event).unwrap();
        }
        let mut notifier = PackNotifier::new(receive, total);
        assert!(notifier.poll());
        notifier
    }
    fn texts(n: &PackNotifier) -> (serde_json::Value, Option<serde_json::Value>) {
        let (title, message) = n.text();
        (title.component(), message.map(|m| m.component()))
    }

    #[test]
    fn the_toast_counts_requests_and_shows_progress() {
        let n = notifier(2, &[RequestStart]);
        let (title, message) = texts(&n);
        assert_eq!(title["translate"], "download.pack.title");
        assert_eq!(title["with"], serde_json::json!([1, 2]));
        assert_eq!(message, None);
        let n = notifier(2, &[RequestStart, DownloadStart(Some(400)), Bytes(100)]);
        assert_eq!(
            texts(&n).1.unwrap(),
            serde_json::json!({"translate": "download.pack.progress.percent", "with": [25]})
        );
        let n = notifier(1, &[RequestStart, DownloadStart(None), Bytes(1280)]);
        assert_eq!(
            texts(&n).1.unwrap()["with"],
            serde_json::json!([{"text": "1.3 KB"}])
        );
    }

    #[test]
    fn a_failed_pack_turns_the_toast_into_the_failure_count() {
        let events = [
            RequestStart,
            RequestFinished(false),
            RequestStart,
            DownloadStart(Some(3)),
            Bytes(3),
        ];
        let (send, receive) = std::sync::mpsc::channel();
        for event in events {
            send.send(event).unwrap();
        }
        let mut n = PackNotifier::new(receive, 2);
        assert!(n.poll());
        // Not the last request yet: still downloading.
        assert_eq!(texts(&n).0["translate"], "download.pack.title");
        send.send(RequestFinished(true)).unwrap();
        drop(send);
        assert!(n.poll(), "the failure toast stays until it slides out");
        let (title, message) = texts(&n);
        assert_eq!(
            title,
            serde_json::json!({"translate": "download.pack.failed", "with": [1, 2]})
        );
        assert_eq!(message, None);
    }

    #[test]
    fn a_finished_batch_without_a_toast_is_dropped() {
        let (send, receive) = std::sync::mpsc::channel::<download::Progress>();
        drop(send);
        assert!(!PackNotifier::new(receive, 1).poll());
    }

    #[test]
    fn sizes_read_as_realms_unit_human_readable() {
        // com.mojang.realmsclient.Unit.humanReadable, run on the 26.3 jar.
        for (bytes, text) in [
            (0, "0 B"),
            (1023, "1023 B"),
            (1024, "1.0 KB"),
            (1280, "1.3 KB"),
            (1535, "1.5 KB"),
            (10_000, "9.8 KB"),
            (1_048_575, "1024.0 KB"),
            (1_048_576, "1.0 MB"),
            (52_428_800, "50.0 MB"),
            (262_144_000, "250.0 MB"),
            (1_073_741_824, "1.0 GB"),
        ] {
            assert_eq!(human_readable(bytes), text, "{bytes}");
        }
    }
}
